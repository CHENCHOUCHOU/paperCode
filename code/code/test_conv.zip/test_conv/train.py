# import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '7'
import sys
import re
import time
from model import *
from utils import *
from os.path import isfile, join
import argparse
import random
import os

import glob


# from modelsummary import summary


def main():
    parser = argparse.ArgumentParser(description='PyTorch Time series forecasting')
    # parser.add_argument('--data', type=str, required=True, help='location of the data file')
    parser.add_argument('--data', type=str, default='../data/nasdaq100_padding.csv', help='location of the data file')
    parser.add_argument('--num_epochs', type=int, default=20, help='upper epoch limit')
    parser.add_argument('--num_layer', type=int, default=1, help='num_layer')
    parser.add_argument('--batch_size', type=int, default=32, help='batch size')
    parser.add_argument('--d_model', type=int, default=128, help='d_model')
    # parser.add_argument('--d_ff', type=int, default=512, help='d_ff')
    # parser.add_argument('--head_num', type=int, default=8, help='head')
    # parser.add_argument('--head_share', type=int, default=32, help='head_share')
    parser.add_argument('--kernel_size', type=int, default=9, help='light conv kernel_size')
    parser.add_argument('--CLIP', type=float, default=20, help='CLIP')
    parser.add_argument('--weight_decay', type=float, default=1e-7, help='weight_decay')
    # 这个窗口设置的优点意思，24是horizon的大小
    parser.add_argument('--window', type=int, default=10, help='window size')
    # 这个参数用于3.6 Autoregressive Component的q^ar
    parser.add_argument('--highway_window', type=int, default=10, help='The window size of the highway component')
    # 这个参数就是隔几步预测，也即论文3.1节中的h
    parser.add_argument('--horizon', type=int, default=30, help='horizon')
    # 控制是否包含no_FR机制的开关，因为这个机制好像在solar上不敏感，但耗时很多，所以测试solar可以先去掉此机制
    # parser.add_argument('--is_no_fc', type=bool, default=False, help='is_no_fr')
    # parser.add_argument('--partial_size', type=int, default=32, help='partial_size')
    # parser.add_argument('--seed', type=int, default=40, help='seed')
    # 此项目is_stepwise禁止打开，因为util中self.rse计算部分并没考虑打开的情况
    # parser.add_argument('--is_stepwise', type=bool, default=False, help='is_stepwise')
    parser.add_argument('--save', type=str, default='best_check', help='path to save the final model')
    parser.add_argument('--log_dir', type=str, default='log_dir', help='log_dir')
    parser.add_argument('--checkpoints_dir', type=str, default='checkpoints_dir', help='checkpoints_dir')
    args = parser.parse_args()

    args.act_cate = 'relu'

    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("cuda: %s" % CUDA)

    data_obj = load_data(args)
    model = make_model(data_obj.feature_num, args).to(args.device)
    test_model = make_model(data_obj.feature_num, args).to(args.device)
    # 加上下面这句就可以用多GPU了，参考：行数较多，已删除，见过往版本
    # model = nn.DataParallel(model)
    # model_opt = NoamOpt(args.d_model, 1, 400, torch.optim.Adam(model.parameters(), lr=0, betas=(0.9, 0.98), eps=1e-9))
    model_opt = torch.optim.Adam(model.parameters())
    # 不需要移到cuda，见https://discuss.pytorch.org/t/why-criterion-cuda-is-not-needed-but-model-cuda-is/17410
    criterion = nn.MSELoss(size_average=False)
    criterion_l1 = nn.L1Loss(size_average=False)

    # 动态加载checkpoint
    # todo 注意这种情况下就最好不要不用同时跑两个数据集和预测步数都相同的程序了，因为存储的checkpoint会相互替换
    checkpoint_path = get_curr_checkpoint_path(args)

    if checkpoint_path and os.path.exists(checkpoint_path):
        log_file, epoch_start_num, best_val, best_epoch_num, early_stop_acc, accumulate_time = load_checkpoint(
            checkpoint_path, model, model_opt, args)
    else:
        # 获取log文件名称，因为不同数据集实验起的名称不一样，同一个数据集每次也要单独分配一个名称记录
        log_file = get_curr_log_name(args)
        epoch_start_num = 0
        # 正无穷，参考：https://stackoverflow.com/questions/34264710/what-is-the-point-of-floatinf-in-python
        best_val = float('inf')
        best_epoch_num = 0
        early_stop_acc = 0
        # 没有checkpoint可加载时accumulate_time清零
        accumulate_time = 0
        # 记录下超参数, 加载checkpoint时是不用再记录一次的
        log_the_parameters(args, log_file)

    # 随机生成种子并打印，这样就不用每次实验都手动设置不同的种子的
    # 加载checkpoint策略时保存随机数就不起作用了，因为重新运行时随机数控制下的随机生成是从开始处而不是从中断处
    # set_rand_seed(args)

    # nelement：Returns the total number of elements in the input tensor，可参看官网，解释的很清楚
    print(f'The model has {count_parameters(model):,} trainable parameters')
    print('start training...')

    total_start_time = time.time()

    for epoch in range(epoch_start_num, args.num_epochs):
        # 下面这句是防止在测试时意外中断导致epoch_start_num等于num_epochs的情况
        if epoch_start_num >= args.num_epochs:
            break
        epoch_start_time = time.time()

        adjust_learning_rate(model_opt, epoch)

        model.train()

        train_rmse, train_mae = run_epoch(data_obj, 0, model,
                                          criterion, criterion_l1, args.batch_size, model_opt, args.CLIP,
                                          weight_decay=args.weight_decay)

        with torch.no_grad():
            model.eval()
            val_rmse, val_mae = run_epoch(data_obj, 1, model, criterion, criterion_l1, args.batch_size)
            with open(log_file, 'a') as result_file:
                result_file.write(
                    f'end of epoch: {epoch:3d}, time: {time.time() - epoch_start_time:5.2f}s, train_rmse: {train_rmse:5.4f}, train_mae: {train_mae:5.4f}, val_rmse: {val_rmse:5.4f}, val_mae: {val_mae:5.4f}\n')

            print(
                f'end of epoch: {epoch:3d}, time: {time.time() - epoch_start_time:5.2f}s, train_rmse: {train_rmse:5.4f}, train_mae: {train_mae:5.4f}, val_rmse: {val_rmse:5.4f}, val_mae: {val_mae:5.4f}\n')

            # Save the model if the validation loss is the best we've seen so far.
            if val_rmse < best_val:
                torch.save(model.state_dict(), get_curr_best_check_path(args))
                best_val = val_rmse
                best_epoch_num = epoch
                early_stop_acc = 0
            else:
                # 早停
                early_stop_acc = early_stop_acc + 1
                # 先暂停早停
                if early_stop_acc > 5 and epoch > 10:
                    break
            if epoch != 0 and epoch in [5, 9]:
                # 加载最好的模型参数
                test_model.load_state_dict(torch.load(get_curr_best_check_path(args)))
                test_criterion = nn.MSELoss(size_average=False)
                test_criterion_l1 = nn.L1Loss(size_average=False)
                temp_test_rmse, temp_test_mae = run_epoch(data_obj, 2,
                                                          test_model, test_criterion, test_criterion_l1,
                                                          args.batch_size)
                with open(log_file, 'a') as result_file:
                    result_file.write(f'\n\ntemp_rmse: {temp_test_rmse:5.4f}\n')
                print(f'temp_rmse: {temp_test_rmse:5.4f}\n')

        # 保存checkpoint
        save_checkpoint(get_curr_checkpoint_path(args), log_file, epoch, model, model_opt, best_val, best_epoch_num,
                        early_stop_acc, time.time() - total_start_time + accumulate_time)

    # test_model = make_model(data_obj.feature_num, args).to(args.device)
    # 加载最好的模型参数
    test_model.load_state_dict(torch.load(get_curr_best_check_path(args)))
    # 下面这句不能在上面加载参数的前面，原因见：
    # https://github.com/bearpaw/pytorch-classification/issues/27
    # https://discuss.pytorch.org/t/missing-keys-unexpected-keys-in-state-dict-when-loading-self-trained-model/22379
    # https://blog.csdn.net/liuweiyuxiang/article/details/82224374
    # test_model = nn.DataParallel(test_model)
    test_criterion = nn.MSELoss(size_average=False)
    test_criterion_l1 = nn.L1Loss(size_average=False)
    # 参考自adaptive span的代码
    with torch.no_grad():
        test_model.eval()
        test_rmse, test_mae = run_epoch(data_obj, 2, test_model,
                                        test_criterion, test_criterion_l1, args.batch_size)

    total_time = time.time() - total_start_time
    total_time = total_time + accumulate_time
    with open(log_file, 'a') as result_file:
        result_file.write(f'best epoch number: {best_epoch_num}\n')
        result_file.write(f'test rmse: {test_rmse}, test mae: {test_mae}\n')
        result_file.write(f'\ntotal_used_time: {total_time}\n')

    print(f'***********test_rse: {test_rmse}, test_mae: {test_mae}****************')
    print(f'total time: {total_time}\n')
    # 运行成功，删除掉用于中间保存的checkpoint，防止下次load_checkpoint时加载上一次运行保存的特定的checkpoint
    os.remove(get_curr_checkpoint_path(args))


if __name__ == "__main__":
    main()

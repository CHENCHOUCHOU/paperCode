# coding:utf-8
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn.utils import weight_norm

import math, copy, time
import random

CUDA = torch.cuda.is_available()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class EncoderDecoder(nn.Module):
    """
    A standard Encoder-Decoder architecture. Base for this and many
    other models.
    """

    def __init__(self, feature_num, args):
        super(EncoderDecoder, self).__init__()

        self.src_embed = nn.Linear(feature_num, args.d_model)

        self.feature_num = feature_num
        self.args = args

        # 用作论文3.6节中的AR模块
        self.hw = args.highway_window
        self.highway = nn.Linear(self.hw, args.horizon)

        self.non_comp_part = ParaNonComprePart(args.d_model, feature_num, args)
        # self.in_space_att = SpaceAttBlock(args.d_model, args.window, args)

        self.gamma1 = nn.Parameter(torch.ones(1))
        self.gamma2 = nn.Parameter(torch.ones(1))
        self.gamma3 = nn.Parameter(torch.ones(1))

    # todo teacher_forcing_ratio可能需要放到超参里去
    def forward(self, src):
        "Take in and process masked src and target sequences."
        src_to_other = self.src_embed(src)

        # torch.Size([32, 168, 256])
        # src_in_att = self.in_space_att(src_to_other.permute(0, 2, 1)).permute(0, 2, 1)

        # 计算AR模块
        # torch.Size([32, 10])
        ar_part_target = src[:, :, -1]
        # torch.Size([32, 30])
        ar_part = self.highway(ar_part_target)

        # 并行atrous模块
        # 共享映射模块
        # torch.Size([32, 30])
        non_comp_part = self.non_comp_part(src_to_other.permute(0, 2, 1))

        return self.gamma1 * ar_part + self.gamma2 * non_comp_part
        # return self.proj(torch.sum(encoder_output, dim=1) / encoder_output.size(1))

    def encode(self, src):
        return self.encoder(src)

    def decode(self, tgt, memory):
        return self.decoder((self.tgt_embed(tgt) * math.sqrt(self.d_model)), memory)


class Generator(nn.Module):
    "Define standard linear generation step."

    def __init__(self, d_model, feature_num):
        super(Generator, self).__init__()
        self.proj = nn.Linear(d_model, feature_num)

    def forward(self, x):
        return self.proj(x)


def clones(module, N):
    "Produce N identical layers."
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])


class LightConv(nn.Module):
    def __init__(self, kernel_size, head_share, args):
        super(LightConv, self).__init__()
        self.kernel_size = kernel_size
        # self.num_heads = num_heads
        # self.d_model = d_model
        self.head_share = head_share
        self.layer1_ker = 15
        self.layer2_ker = 13
        self.layer3_ker = 11
        self.layer4_ker = 9

        self.simi_num = 1

        self.conv_layer1 = ConvLayer(head_share, 168, self.layer1_ker, 3, 2, args, is_first_pool=True)
        self.conv_self_att_layer1 = ConvSimisLayer(head_share, 168 // 2, self.layer1_ker, args, self.simi_num)

        self.conv_layer2 = ConvLayer(head_share, 168 // 2, self.layer2_ker, 3, 2, args)
        self.conv_self_att_layer2 = ConvSimisLayer(head_share, 168 // 4, self.layer2_ker, args, self.simi_num)

        self.conv_layer3 = ConvLayer(head_share, 168 // 4, self.layer3_ker, 3, 2, args)
        self.conv_self_att_layer3 = ConvSimisLayer(head_share, 168 // 8, self.layer3_ker, args, self.simi_num)

        self.conv_layer4 = ConvLayer(head_share, 168 // 8, self.layer4_ker, 5, 3, args)
        self.conv_self_att_layer4 = ConvSimisLayer(head_share, 168 // 24, self.layer4_ker, args, self.simi_num)

        self.skip_connect1 = nn.Sequential(
            nn.Linear(168, 168 // 4),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
            nn.Linear(168 // 4, 168 // 2)
        )
        self.skip_connect2 = nn.Sequential(
            nn.Linear(168 // 2, 168 // 8),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
            nn.Linear(168 // 8, 168 // 4)
        )
        self.skip_connect3 = nn.Sequential(
            nn.Linear(168 // 4, 10),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
            nn.Linear(10, 168 // 8)
        )
        self.skip_connect4 = nn.Sequential(
            nn.Linear(168 // 8, 5),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
            nn.Linear(5, 7)
        )
        self.norm1 = nn.LayerNorm(head_share)
        self.norm2 = nn.LayerNorm(head_share)
        self.norm3 = nn.LayerNorm(head_share)
        self.norm4 = nn.LayerNorm(head_share)

        self.gamma1_1 = nn.Parameter(torch.ones(1))
        self.gamma1_2 = nn.Parameter(torch.ones(1))
        self.gamma1_3 = nn.Parameter(torch.ones(1))

        self.gamma2_1 = nn.Parameter(torch.ones(1))
        self.gamma2_2 = nn.Parameter(torch.ones(1))
        self.gamma2_3 = nn.Parameter(torch.ones(1))

        self.gamma3_1 = nn.Parameter(torch.ones(1))
        self.gamma3_2 = nn.Parameter(torch.ones(1))
        self.gamma3_3 = nn.Parameter(torch.ones(1))

        self.gamma4_1 = nn.Parameter(torch.ones(1))
        self.gamma4_2 = nn.Parameter(torch.ones(1))
        self.gamma4_3 = nn.Parameter(torch.ones(1))

    # input: torch.Size([128, 168, 512])
    # Output: BxTxC, i.e.(batch_size, timesteps, input_size)
    def forward(self, input):
        # Input: BxCxT, i.e.(batch_size, input_size, timesteps)
        input = input.permute(0, 2, 1).contiguous()
        B, C, T = input.size()
        H = self.head_share
        input = input.view(-1, H, T)

        conv_layer1_out = self.conv_layer1(input)
        conv_layer1_simi_out = self.conv_self_att_layer1(conv_layer1_out)
        skip_conv_layer1_out = self.skip_connect1(input)
        # torch.Size([1024, 8, 84])
        final_conv_layer1_out = self.gamma1_1 * conv_layer1_simi_out + self.gamma1_2 * conv_layer1_out + self.gamma1_3 * skip_conv_layer1_out
        layer_normed_layer1_out = self.norm1(final_conv_layer1_out.permute(0, 2, 1)).permute(0, 2, 1)

        conv_layer2_out = self.conv_layer2(layer_normed_layer1_out)
        conv_layer2_simi_out = self.conv_self_att_layer2(conv_layer2_out)
        skip_conv_layer2_out = self.skip_connect2(final_conv_layer1_out)
        # torch.Size([1024, 8, 42])
        final_conv_layer2_out = self.gamma2_1 * conv_layer2_simi_out + self.gamma2_2 * conv_layer2_out + self.gamma2_3 * skip_conv_layer2_out
        layer_normed_layer2_out = self.norm2(final_conv_layer2_out.permute(0, 2, 1)).permute(0, 2, 1)

        # torch.Size([1024, 8, 21])
        conv_layer3_out = self.conv_layer3(layer_normed_layer2_out)
        conv_layer3_simi_out = self.conv_self_att_layer3(conv_layer3_out)
        skip_conv_layer3_out = self.skip_connect3(final_conv_layer2_out)
        final_conv_layer3_out = self.gamma3_1 * conv_layer3_simi_out + self.gamma3_2 * conv_layer3_out + self.gamma3_3 * skip_conv_layer3_out
        # torch.Size([1024, 8, 21])
        layer_normed_layer3_out = self.norm3(final_conv_layer3_out.permute(0, 2, 1)).permute(0, 2, 1)

        # torch.Size([1024, 8, 7])
        conv_layer4_out = self.conv_layer4(layer_normed_layer3_out)
        conv_layer4_simi_out = self.conv_self_att_layer4(conv_layer4_out)
        skip_conv_layer4_out = self.skip_connect4(final_conv_layer3_out)
        final_conv_layer4_out = self.gamma4_1 * conv_layer4_simi_out + self.gamma4_2 * conv_layer4_out + self.gamma4_3 * skip_conv_layer4_out
        layer_normed_layer4_out = self.norm4(final_conv_layer4_out.permute(0, 2, 1)).permute(0, 2, 1)

        # torch.Size([32, 256, 7])
        output_temp = layer_normed_layer4_out.reshape(B, C, -1)
        # torch.Size([32, 7, 256])
        output = output_temp.permute(0, 2, 1)

        # torch.Size([32, 21, 256])
        return output


class ConvLayer(nn.Module):
    def __init__(self, conv_in_channel, space_size, kernel_size, pool_size, stride_size, args, is_first_pool=False):
        super(ConvLayer, self).__init__()

        self.conv_block = MultibranchBlock(conv_in_channel, space_size, kernel_size, args)
        self.act = nn.ReLU() if args.act_cate == 'relu' else nn.ELU()
        self.is_first_pool = is_first_pool
        if is_first_pool:
            self.avg_adap = nn.AdaptiveAvgPool1d(output_size=84)
            self.max_adap = nn.AdaptiveMaxPool1d(output_size=84)
        else:
            self.avg_max = AvgMaxBlock(pool_size, stride_size)

    def forward(self, input):
        conv_block_out = self.conv_block(input)
        acted = self.act(conv_block_out)

        if self.is_first_pool:
            avg_max_out = self.avg_adap(acted) + self.max_adap(acted)
        else:
            avg_max_out = self.avg_max(acted)

        return avg_max_out


class ConvSelfAttLayer(nn.Module):
    def __init__(self, conv_in_channel, ker_size, args):
        super(ConvSelfAttLayer, self).__init__()

        self.ker_size = ker_size
        self.conv_q_1 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel // 8,
                                  kernel_size=1,
                                  padding=0)
        self.conv_q_2 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel // 8,
                                  kernel_size=self.ker_size - 4,
                                  padding=(self.ker_size - 5) // 2)
        self.conv_q_3 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel // 8,
                                  kernel_size=self.ker_size,
                                  padding=(self.ker_size - 1) // 2)

        self.conv_k_1 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel // 8,
                                  kernel_size=1,
                                  padding=0, )
        self.conv_k_2 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel // 8,
                                  kernel_size=self.ker_size - 4,
                                  padding=(self.ker_size - 5) // 2)
        self.conv_k_3 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel // 8,
                                  kernel_size=self.ker_size,
                                  padding=(self.ker_size - 1) // 2)
        self.conv_v_1 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel,
                                  kernel_size=1,
                                  padding=0, )
        self.conv_v_2 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel,
                                  kernel_size=self.ker_size - 4,
                                  padding=(self.ker_size - 5) // 2)
        self.conv_v_3 = nn.Conv1d(in_channels=conv_in_channel,
                                  out_channels=conv_in_channel,
                                  kernel_size=self.ker_size,
                                  padding=(self.ker_size - 1) // 2)

        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)
        self.comp_skip_conv = nn.Conv1d(in_channels=conv_in_channel,
                                        out_channels=conv_in_channel,
                                        kernel_size=self.ker_size,
                                        padding=(self.ker_size - 1) // 2,
                                        groups=conv_in_channel
                                        )

        self.act = nn.ReLU() if args.act_cate == 'relu' else nn.ELU()

    # torch.Size([256, 32, 84])
    def forward(self, input):
        # torch.Size([256, 84, 4])
        query = (self.conv_q_1(input) + self.conv_q_2(input) + self.conv_q_3(input)).permute(0, 2, 1)
        # torch.Size([256, 4, 84])
        key = self.conv_k_1(input) + self.conv_k_2(input) + self.conv_k_3(input)
        # torch.Size([32, 256, 84])
        val = self.conv_v_1(input) + self.conv_v_2(input) + self.conv_v_3(input)

        # torch.Size([32, 84, 84])
        energy = torch.bmm(query, key)
        energy_new = torch.max(energy, -1, keepdim=True)[0].expand_as(energy) - energy
        attention = self.softmax(energy_new)
        # torch.Size([32, 256, 84])
        out = torch.bmm(val, attention.permute(0, 2, 1))
        final_out = self.gamma * out + self.comp_skip_conv(input)

        acted = self.act(final_out)

        return acted


class ConvSimiLayer(nn.Module):
    def __init__(self, conv_in_channel, space_size, kernel_size, args):
        super(ConvSimiLayer, self).__init__()

        self.conv_block = MultibranchBlock(conv_in_channel, space_size, kernel_size, args)
        self.act = nn.ReLU() if args.act_cate == 'relu' else nn.ELU()

    def forward(self, input):
        conv_block_out = self.conv_block(input)
        acted = self.act(conv_block_out)

        return acted


class ConvSimisLayer(nn.Module):
    def __init__(self, conv_in_channel, space_size, kernel_size, args, repeat_num):
        super(ConvSimisLayer, self).__init__()

        self.conv_blocks = nn.ModuleList(
            [ConvSimiLayer(conv_in_channel, space_size, kernel_size, args) for _ in range(repeat_num)]
        )

    def forward(self, input):
        conv_block_out = input
        for conv_op in self.conv_blocks:
            conv_block_out = conv_op(conv_block_out)

        return conv_block_out + input


class MultibranchBlock(nn.Module):
    def __init__(self, in_channels, space_size, kernel_size, args):
        super(MultibranchBlock, self).__init__()

        self.kernel_size = kernel_size
        self.conv0 = nn.Conv1d(in_channels=in_channels,
                               out_channels=in_channels,
                               kernel_size=1,
                               padding=0,
                               groups=in_channels)
        self.conv1 = nn.Conv1d(in_channels=in_channels,
                               out_channels=in_channels,
                               kernel_size=kernel_size,
                               padding=(kernel_size - 1) // 2,
                               groups=in_channels)
        self.conv2 = nn.Conv1d(in_channels=in_channels,
                               out_channels=in_channels,
                               kernel_size=kernel_size + 4,
                               padding=(kernel_size + 3) // 2,
                               groups=in_channels)
        self.conv_atrous3 = nn.Conv1d(in_channels=in_channels,
                                      out_channels=in_channels,
                                      kernel_size=5,
                                      dilation=3,
                                      padding=6,
                                      groups=in_channels)

        # self.self_att = MultiHeadedAttention(2, in_channels)

        # self.space_att0 = SpaceAttBlock(in_channels, space_size, args)
        # self.space_att1 = SpaceAttBlock(in_channels, space_size, args)
        # self.space_att2 = SpaceAttBlock(in_channels, space_size, args)
        # self.space_att3 = SpaceAttBlock(in_channels, space_size, args)

    def forward(self, input):
        out_conv0 = self.conv0(input)

        out_conv1 = self.conv1(input)

        out_conv2 = self.conv2(input)

        out_conv3 = self.conv_atrous3(input)

        fuse_out = out_conv0 + out_conv1 + out_conv2 + out_conv3

        return fuse_out


class AvgMaxBlock(nn.Module):
    def __init__(self, pool_sieze, stride_size):
        super(AvgMaxBlock, self).__init__()
        self.avg_pooling = nn.AvgPool1d(pool_sieze, padding=(pool_sieze - 1) // 2, stride=stride_size)
        # self.max_pooling = nn.MaxPool1d(pool_sieze, padding=(pool_sieze - 1) // 2, stride=stride_size)

    # torch.Size([1024, 8, 168])
    def forward(self, input):
        # torch.Size([1024, 8, 84])
        avg_pool = self.avg_pooling(input)
        # torch.Size([1024, 8, 84])
        # max_pool = self.max_pooling(input)
        final_out = avg_pool

        return final_out


class SpaceAttBlock(nn.Module):
    def __init__(self, channel_in, space_in, args):
        super(SpaceAttBlock, self).__init__()

        self.space_mlp = nn.Sequential(
            nn.Linear(space_in, space_in // 2),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
            nn.Linear(space_in // 2, space_in),
            nn.Sigmoid()
        )

        # self.hori_mlp = nn.Sequential(
        #     nn.Linear(channel_in, channel_in // 2),
        #     nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
        #     nn.Linear(channel_in // 2, channel_in),
        #     nn.Sigmoid()
        # )
        #
        # self.corre_mlp = nn.Sequential(
        #     nn.Linear(space_in, space_in // 4),
        #     nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
        #     nn.Linear(space_in // 4, 1),
        #     nn.Sigmoid()
        # )
        self.gamma1 = nn.Parameter(torch.ones(1))
        self.gamma2 = nn.Parameter(torch.ones(1))
        self.gamma3 = nn.Parameter(torch.ones(1))

    # torch.Size([1024, 8, 168])
    def forward(self, input):
        # torch.Size([1024, 168])
        # hori_att_in = self.hori_mlp(input.permute(0, 2, 1)).permute(0, 2, 1) * input
        # space_avg_pool = hori_att_in.mean(-2)
        # channel_corre_out = cal_corr(input)
        # torch.Size([1024, 168])
        avg_att_raw = self.space_mlp(input.mean(-2))
        # corre_att_raw = self.corre_mlp(channel_corre_out).squeeze(2)
        space_scale = avg_att_raw.unsqueeze(1)

        # torch.Size([32, 8, 168])
        final_fuse_out = space_scale * input

        return final_fuse_out


# input: torch.Size([128, 168, 256])
# torch.Size([1024, 168, 8])
def cal_corr(x):
    # torch.Size([32, 256])
    std_x = torch.std(x, 1, True).unsqueeze(1)
    # torch.Size([32, 168, 256])
    meaned_x = (x - torch.mean(x, 1, True)) / std_x
    # torch.Size([32, 256, 256])
    corre_numerator = torch.matmul(meaned_x.transpose(-2, -1), meaned_x)
    # torch.Size([32, 256, 1])
    corre_denominator_left = torch.sqrt(torch.sum(meaned_x * meaned_x, 1, True)).reshape(x.size(0), -1, 1)
    # torch.Size([32, 1, 256])
    corre_denominator_right = torch.sqrt(torch.sum(meaned_x * meaned_x, 1, True))
    # torch.Size([32, 256, 256])
    corre = corre_numerator / (corre_denominator_left * corre_denominator_right + 1e-8)

    return corre


# 和原始的SKnet的机制不太一样，这里融合了均值和最大值，原始的只有均值，而且那里是对space维的信息进行聚合，这里是channel
class SKBlock(nn.Module):
    def __init__(self, space_in):
        super(SKBlock, self).__init__()

        self.fuse_num = 4
        self.space_mlp = nn.Sequential(
            nn.Linear(space_in, space_in // 2),
            nn.ReLU(),
            nn.Linear(space_in // 2, space_in * self.fuse_num),
            nn.Sigmoid()
        )

    # torch.Size([1024, 8, 168])
    def forward(self, input):
        B, C, S = input.size()
        # torch.Size([1024, 168])
        space_avg_pool = input.mean(-2)
        space_max_pool = input.max(-2)[0]
        # torch.Size([1024, 168])
        avg_att_raw = self.space_mlp(space_avg_pool)
        max_att_raw = self.space_mlp(space_max_pool)
        space_scale = (avg_att_raw + max_att_raw).reshape(B, self.fuse_num, S)
        coeffs = space_scale.chunk(self.fuse_num, 1)

        return coeffs


class ParaNonComprePart(nn.Module):
    def __init__(self, in_channel, feature_num, args):
        super(ParaNonComprePart, self).__init__()
        self.repeat_num = 4
        self.horizon = args.horizon

        self.conv_blocks = nn.ModuleList(
            [NoneCompreBlock(in_channel, 2 ** i, args) for i in range(self.repeat_num)]
        )

        self.proj = nn.Linear(in_channel, args.horizon)
        # self.mlp = nn.Sequential(
        #     nn.Linear(in_channel, in_channel // 8),
        #     nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
        #     nn.Linear(in_channel // 8, in_channel)
        # )

    # torch.Size([32, 128, 10])
    def forward(self, input):
        conv_out = input
        for conv_op in self.conv_blocks:
            conv_out = conv_op(conv_out)

        # torch.Size([32, 128])
        avg_pool = conv_out.mean(-1)
        # max_pool = normed_layer4_out.max(-1)[0]
        # avg_att_raw = self.mlp(avg_pool)
        # max_att_raw = self.mlp(max_pool)
        # # torch.Size([32, 256])
        # avg_co = F.sigmoid(avg_att_raw)
        # max_co = F.sigmoid(max_att_raw)

        # final_out = avg_pool.permute(0, 2, 1)

        # torch.Size([32, 30])
        atrous_part_out = self.proj(avg_pool)

        return atrous_part_out


class NoneCompreBlock(nn.Module):
    def __init__(self, in_channel, di_rate, args):
        super(NoneCompreBlock, self).__init__()

        self.conv_blocks = nn.ModuleList(
            [NonCompreSimiBlock(in_channel, di_rate, args) for _ in range(2)]
        )

        self.norm = nn.LayerNorm(in_channel)

    def forward(self, input):
        conv_block_out = input
        for conv_op in self.conv_blocks:
            conv_block_out = conv_op(conv_block_out)

        sum_out = conv_block_out + input

        return self.norm(sum_out.permute(0, 2, 1)).permute(0, 2, 1)


class NonCompreSimiBlock(nn.Module):
    def __init__(self, in_channel, di_rate, args):
        super(NonCompreSimiBlock, self).__init__()

        # self.conv_atrous1 = nn.Conv1d(in_channels=in_channel,
        #                               out_channels=in_channel,
        #                               kernel_size=args.kernel_size - 4,
        #                               dilation=di_rate,
        #                               padding=(args.kernel_size - 5) * di_rate // 2,
        #                               groups=in_channel // 4)

        self.conv_atrous2 = nn.Conv1d(in_channels=in_channel,
                                      out_channels=in_channel,
                                      kernel_size=args.kernel_size,
                                      dilation=di_rate,
                                      padding=(args.kernel_size - 1) * di_rate // 2)
        # self.conv_3 = nn.Conv1d(in_channels=in_channel,
        #                         out_channels=in_channel,
        #                         kernel_size=9,
        #                         padding=4,
        #                         groups=in_channel)
        # self.conv_4 = nn.Conv1d(in_channels=in_channel,
        #                         out_channels=in_channel,
        #                         kernel_size=5,
        #                         padding=2,
        #                         groups=in_channel)
        # self.conv_5 = nn.Conv1d(in_channels=in_channel,
        #                         out_channels=in_channel,
        #                         kernel_size=1,
        #                         padding=0,
        #                         groups=in_channel)

        self.act = nn.ReLU() if args.act_cate == 'relu' else nn.ELU()

    def forward(self, input):
        # atrous1_out = self.conv_atrous1(input)
        atrous2_out = self.conv_atrous2(input)

        acted_out = self.act(atrous2_out)

        return acted_out


class ParaAtrousPart(nn.Module):
    def __init__(self, in_channel, feature_num, args):
        super(ParaAtrousPart, self).__init__()

        self.atrous_layer1 = ParaAtrousBlock(in_channel, 3, 2, args, is_first_pool=True)
        self.atrous_simi_layer1 = ParaAtrousSimiBlock(in_channel, args)
        self.atrous_layer2 = ParaAtrousBlock(in_channel, 3, 2, args)
        self.atrous_simi_layer2 = ParaAtrousSimiBlock(in_channel, args)
        self.atrous_layer3 = ParaAtrousBlock(in_channel, 3, 2, args)
        self.atrous_simi_layer3 = ParaAtrousSimiBlock(in_channel, args)
        self.atrous_layer4 = ParaAtrousBlock(in_channel, 5, 3, args)
        self.atrous_simi_layer4 = ParaAtrousSimiBlock(in_channel, args)

        self.skip_connect1 = nn.Sequential(
            nn.Linear(168, 168 // 2),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU()
        )
        self.skip_connect2 = nn.Sequential(
            nn.Linear(168 // 2, 168 // 4),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU()
        )
        self.skip_connect3 = nn.Sequential(
            nn.Linear(168 // 4, 168 // 8),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU()
        )
        self.skip_connect4 = nn.Sequential(
            nn.Linear(168 // 8, 168 // 24),
            nn.ReLU() if args.act_cate == 'relu' else nn.ELU()
        )

        self.norm1 = nn.LayerNorm(in_channel)
        self.norm2 = nn.LayerNorm(in_channel)
        self.norm3 = nn.LayerNorm(in_channel)
        self.norm4 = nn.LayerNorm(in_channel)

        self.proj = nn.Linear(in_channel, feature_num)
        # self.mlp = nn.Sequential(
        #     nn.Linear(in_channel, in_channel // 8),
        #     nn.ReLU() if args.act_cate == 'relu' else nn.ELU(),
        #     nn.Linear(in_channel // 8, in_channel)
        # )

    def forward(self, input):
        atrous_layer1_out = self.atrous_layer1(input)
        atrous_simi_layer1_out = self.atrous_simi_layer1(atrous_layer1_out)
        skip_out1 = self.skip_connect1(input)
        final_layer1_out = atrous_simi_layer1_out + skip_out1

        atrous_layer2_in = self.norm1(final_layer1_out.permute(0, 2, 1)).permute(0, 2, 1)
        atrous_layer2_out = self.atrous_layer2(atrous_layer2_in)
        atrous_simi_layer2_out = self.atrous_simi_layer2(atrous_layer2_out)
        skip_out2 = self.skip_connect2(final_layer1_out)
        final_layer2_out = atrous_simi_layer2_out + skip_out2

        atrous_layer3_in = self.norm2(final_layer2_out.permute(0, 2, 1)).permute(0, 2, 1)
        atrous_layer3_out = self.atrous_layer3(atrous_layer3_in)
        atrous_simi_layer3_out = self.atrous_simi_layer3(atrous_layer3_out)
        skip_out3 = self.skip_connect3(final_layer2_out)
        final_layer3_out = atrous_simi_layer3_out + skip_out3

        # torch.Size([32, 256, 21])
        atrous_layer4_in = self.norm3(final_layer3_out.permute(0, 2, 1)).permute(0, 2, 1)
        # torch.Size([32, 256, 7])
        atrous_layer4_out = self.atrous_layer4(atrous_layer4_in)
        atrous_simi_layer4_out = self.atrous_simi_layer4(atrous_layer4_out)
        skip_out4 = self.skip_connect4(final_layer3_out)
        final_layer4_out = atrous_simi_layer4_out + skip_out4

        # torch.Size([32, 256, 21])
        normed_layer4_out = self.norm4(final_layer4_out.permute(0, 2, 1)).permute(0, 2, 1)

        # torch.Size([32, 256])
        avg_pool = normed_layer4_out.mean(-1)
        # max_pool = normed_layer4_out.max(-1)[0]
        # avg_att_raw = self.mlp(avg_pool)
        # max_att_raw = self.mlp(max_pool)
        # # torch.Size([32, 256])
        # avg_co = F.sigmoid(avg_att_raw)
        # max_co = F.sigmoid(max_att_raw)

        final_out = avg_pool

        # torch.Size([32, 137])
        atrous_part_out = self.proj(final_out)

        return atrous_part_out


class ParaAtrousBlock(nn.Module):
    def __init__(self, in_channel, pool_size, stride_size, args, is_first_pool=False):
        super(ParaAtrousBlock, self).__init__()

        self.simi_atrou = ParaAtrousSimiBlock(in_channel, args)
        self.is_first_pool = is_first_pool
        if is_first_pool:
            self.avg_adap = nn.AdaptiveAvgPool1d(output_size=84)
            # self.max_adap = nn.AdaptiveMaxPool1d(output_size=84)
        else:
            self.pooling_block = AvgMaxBlock(pool_size, stride_size)

    def forward(self, input):

        acted_out = self.simi_atrou(input)

        if self.is_first_pool:
            pooling_out = self.avg_adap(acted_out)
        else:
            pooling_out = self.pooling_block(acted_out)

        return pooling_out


class ParaAtrousSimiBlock(nn.Module):
    def __init__(self, in_channel, args):
        super(ParaAtrousSimiBlock, self).__init__()

        # self.conv_atrous1 = nn.Conv1d(in_channels=in_channel,
        #                               out_channels=in_channel,
        #                               kernel_size=3,
        #                               dilation=int(3),
        #                               padding=int(3),
        #                               groups=in_channel)

        self.conv_atrous2 = nn.Conv1d(in_channels=in_channel,
                                      out_channels=in_channel,
                                      kernel_size=5,
                                      dilation=5,
                                      padding=10,
                                      groups=in_channel)

        self.conv_3 = nn.Conv1d(in_channels=in_channel,
                                out_channels=in_channel,
                                kernel_size=9,
                                padding=4,
                                groups=in_channel)
        self.conv_4 = nn.Conv1d(in_channels=in_channel,
                                out_channels=in_channel,
                                kernel_size=5,
                                padding=2,
                                groups=in_channel)
        self.conv_5 = nn.Conv1d(in_channels=in_channel,
                                out_channels=in_channel,
                                kernel_size=1,
                                padding=0,
                                groups=in_channel)

        self.act = nn.ReLU() if args.act_cate == 'relu' else nn.ELU()

    def forward(self, input):
        # atrous1_out = self.conv_atrous1(input)
        atrous2_out = self.conv_atrous2(input)
        conv3_out = self.conv_3(input)
        conv4_out = self.conv_4(input)
        conv5_out = self.conv_5(input)

        sum_atrou_out = atrous2_out + conv3_out + conv4_out + conv5_out
        acted_out = self.act(sum_atrou_out)

        return acted_out


def channel_shuffle(x, groups=2):
    batchsize, channel, step = x.size()

    channels_per_group = channel // groups

    # reshape
    # torch.Size([1, 2, 4, 168])
    shuffle_x = x.view(batchsize, groups, channels_per_group, step)

    # transpose
    # - contiguous() required if transpose() is used before view().
    #   See https://github.com/pytorch/pytorch/issues/764
    # torch.Size([1, 4, 2, 28, 28])
    shuffle_x = torch.transpose(shuffle_x, 1, 2).contiguous()

    # flatten
    # torch.Size([1, 8, 168])
    shuffle_x = shuffle_x.view(batchsize, -1, step)

    return shuffle_x


# 看原文这里的上面有些很不错的注释
class SublayerConnection(nn.Module):
    """
    A residual connection followed by a layer norm.
    Note for code simplicity the norm is first as opposed to last.
    """

    def __init__(self, size, dropout):
        super(SublayerConnection, self).__init__()
        self.norm = nn.LayerNorm(size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):
        "Apply residual connection to any sublayer with the same size."
        return x + self.dropout(sublayer(self.norm(x)))


def attention(query, key, value, dropout=None):
    "Compute 'Scaled Dot Product Attention'"
    # todo 调试一下d_k的值是否正确
    d_k = query.size(-1)
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)
    p_attn = F.softmax(scores, dim=-1)
    if dropout is not None:
        # todo 分析一下这里的dropout，是对哪些维度进行dropout
        p_attn = dropout(p_attn)
    return torch.matmul(p_attn, value), p_attn


class PositionwiseFeedForward(nn.Module):
    "Implements FFN equation."

    def __init__(self, d_model, d_ff, dropout=0.1):
        super(PositionwiseFeedForward, self).__init__()
        self.w_1 = nn.Linear(d_model, d_ff)
        self.w_2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        return self.w_2(self.dropout(F.relu(self.w_1(x))))


def gen_timing_signal(length, d_model):
    # Compute the positional encodings once in log space.
    pe = torch.zeros(length, d_model)
    # 间隔需要是1.0而不是1，因为sin计算需要的是实数而不是整数
    position = torch.arange(0, length, 1.0).unsqueeze(1)
    # torch.arange中必须是2.0而不能是2，否则会是整数，无法做指数运算
    div_term = torch.exp(torch.arange(0, d_model, 2.0) * -(math.log(10000.0) / d_model))
    # 比如对于某一行，position是固定的，而div_term上一行也已经计算好了即也已经固定了，那么其实就是pe某一行相邻的奇数位置或偶数位置
    # 其实是同一个数值的sin以及cos的不同作用，准确的实现了原文的公式
    pe[:, 0::2] = torch.sin(position * div_term)
    pe[:, 1::2] = torch.cos(position * div_term)
    # pe: torch.Size([1, 5000, 256])
    pe = pe.unsqueeze(0)
    return pe


class PositionalEncoding(nn.Module):
    "Implement the PE function."

    def __init__(self, d_model, dropout, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        # Compute the positional encodings once in log space.
        pe = torch.zeros(max_len, d_model)
        # 间隔需要是1.0而不是1，因为sin计算需要的是实数而不是整数
        position = torch.arange(0, max_len, 1.0).unsqueeze(1)
        # torch.arange中必须是2.0而不能是2，否则会是整数，无法做指数运算
        div_term = torch.exp(torch.arange(0, d_model, 2.0) * -(math.log(10000.0) / d_model))
        # 比如对于某一行，position是固定的，而div_term上一行也已经计算好了即也已经固定了，那么其实就是pe某一行相邻的奇数位置或偶数位置
        # 其实是同一个数值的sin以及cos的不同作用，准确的实现了原文的公式
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        # pe: torch.Size([1, 5000, 256])
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + Variable(self.pe[:, :x.size(1)], requires_grad=False)
        return self.dropout(x)


# Here we define a function that takes in hyperparameters and produces a full model.
def make_model(feature_num, args, dropout=0.5):
    "Helper: Construct a model from hyperparameters."
    c = copy.deepcopy

    model = EncoderDecoder(feature_num, args)

    # This was important from their code.
    # Initialize parameters with Glorot / fan_avg.
    for p in model.parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform(p)
    return model


def run_epoch(data, state, model, criterion, criterion_l1, batch_size, optim=None, clip=None,
              weight_decay=1e-7):
    "Standard Training and Logging Function"
    start = time.time()
    total_loss = 0
    total_loss_l1 = 0
    n_samples = 0
    is_shuffle = False
    if optim is not None:
        is_shuffle = True

    predict = None
    test = None
    if state == 0:
        Xs = data.train_set[0]
        Ys = data.train_set[1]
    elif state == 1:
        Xs = data.valid_set[0]
        Ys = data.valid_set[1]
    elif state == 2:
        Xs = data.test_set[0]
        Ys = data.test_set[1]
    # X：torch.Size([32, 10, 82])   Y：torch.Size([32, 30])
    for X, Y in data.get_batches(Xs, Ys, batch_size, shuffle=is_shuffle):

        model.zero_grad()

        # true_Y里面提取出了真正要预测的Y
        # true_Y: torch.Size([32, 8])
        # true_Y = Y[:, -1] if is_stepwise else Y

        # torch.Size([32, 30])
        output = model(X)

        if predict is None:
            predict = output
            test = Y
        else:
            # torch.cat默认按第0维拼接，即竖着拼接
            predict = torch.cat((predict, output))
            test = torch.cat((test, Y))

        scaled_out = output * data.target_stdev + data.target_mean
        scaled_Y = Y * data.target_stdev + data.target_mean
        scaled_loss = criterion(scaled_out, scaled_Y)
        scaled_loss_l1 = criterion_l1(scaled_out, scaled_Y)
        # loss：torch.Size([])，即是一个标量tensor
        loss = criterion(output, Y)
        loss_l1 = criterion_l1(output, Y)

        if optim is not None:
            # 去除bias的权重衰减
            # 参考：https://stackoverflow.com/questions/42704283/adding-l1-l2-regularization-in-pytorch
            l2_reg = 0
            for name, param in model.named_parameters():
                if param.requires_grad and 'weight' in name:
                    l2_reg += torch.norm(param)
            sum_loss = loss + weight_decay * l2_reg
            sum_loss.backward()
            if clip is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
            optim.step()

        total_loss += scaled_loss.item()
        total_loss_l1 += scaled_loss_l1.item()
        n_samples += (output.size(0) * data.feature_num)

    rmse = math.sqrt(total_loss / n_samples)
    mae = total_loss_l1 / n_samples
    # 担心出现除以0的问题，暂不处理
    # mape =

    return rmse, mae


# def run_epoch(data, X, Y, model, criterion, criterion_l1, batch_size, optim=None, clip=None, weight_decay=1e-7):
#     "Standard Training and Logging Function"
#     start = time.time()
#     total_loss = 0
#     total_loss_l1 = 0
#     n_samples = 0
#     is_shuffle = False
#     if optim is not None:
#         is_shuffle = True
#
#     predict = None
#     test = None
#     # X：torch.Size([32, 10, 82])   Y：torch.Size([32, 30])
#     for X, Y in data.get_batches(X, Y, batch_size, shuffle=is_shuffle):
#
#         model.zero_grad()
#
#         # true_Y里面提取出了真正要预测的Y
#         # true_Y: torch.Size([32, 8])
#         # true_Y = Y[:, -1] if is_stepwise else Y
#
#         # torch.Size([32, 30])
#         output = model(X)
#
#         if predict is None:
#             predict = output
#             test = Y
#         else:
#             # torch.cat默认按第0维拼接，即竖着拼接
#             predict = torch.cat((predict, output))
#             test = torch.cat((test, Y))
#
#         scaled_out = output * data.target_stdev + data.target_mean
#         scaled_Y = Y * data.target_stdev + data.target_mean
#         scaled_loss = criterion(scaled_out, scaled_Y)
#         scaled_loss_l1 = criterion_l1(scaled_out, scaled_Y)
#         # loss：torch.Size([])，即是一个标量tensor
#         loss = criterion(output, Y)
#         loss_l1 = criterion_l1(output, Y)
#
#         if optim is not None:
#             # 去除bias的权重衰减
#             # 参考：https://stackoverflow.com/questions/42704283/adding-l1-l2-regularization-in-pytorch
#             l2_reg = 0
#             for name, param in model.named_parameters():
#                 if param.requires_grad and 'weight' in name:
#                     l2_reg += torch.norm(param)
#             sum_loss = loss + weight_decay * l2_reg
#             sum_loss.backward()
#             if clip is not None:
#                 torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
#             optim.step()
#
#         total_loss += scaled_loss.item()
#         total_loss_l1 += scaled_loss_l1.item()
#         n_samples += (output.size(0) * data.feature_num)
#
#     rmse = math.sqrt(total_loss / n_samples)
#     mae = total_loss_l1 / n_samples
#     # 担心出现除以0的问题，暂不处理
#     # mape =
#
#     return rmse, mae


def Tensor(*args):
    x = torch.Tensor(*args)
    return x.cuda() if CUDA else x


def LongTensor(*args):
    x = torch.LongTensor(*args)
    return x.cuda() if CUDA else x


def FloatTensor(*args):
    x = torch.FloatTensor(*args)
    return x.cuda() if CUDA else x


# 这个用法不错，或者直接item()也许更好一点，不用这么复杂
def scalar(x):
    return x.view(-1).data.tolist()[0]

# coding:utf-8
import torch
import numpy as np
import pandas as pd
import os
import glob
from os.path import join
import random
import time


# 这个可能是为了转换成样本方差吧，所以才对标准差乘了系数np.sqrt((len(x) - 1.) / (len(x)))，不过因为样本很大，该系数几乎为1
# x: torch.Size([5261, 321])
def normal_std(x):
    # 因为没有加dim指定维度，所以是算的所有元素的标准差
    return x.std() * np.sqrt((len(x) - 1.) / (len(x)))


# todo 下面链接中除以了1000来加快收敛速度，我们这里或许也应该每列特征值除以该列的最大值：
#  https://medium.com/inside-machine-learning/what-is-a-transformer-d07dd1fbec04,
#  只是注意在结果输出时类似LSTNet把scale再乘回来
class Dataset(object):
    def __init__(self, args, train_percent=0.8, valid_percent=0.1):
        self.horizon = args.horizon
        self.window = args.window
        # 为了加快调试速度，我对np.loadtxt加max_rows限制读取数据的长度，调试好后再取消
        # <class 'tuple'>: (40560, 82)
        self.raw_data = np.array(pd.read_csv(args.data))
        self.data_num, self.feature_num = self.raw_data.shape

        self.target_mean = 0
        self.target_stdev = 0

        # train_end_num: 15782  valid_end_num: 21043   test_end_num: 26304
        train_end_num = int(train_percent * self.data_num)
        valid_end_num = int((train_percent + valid_percent) * self.data_num)
        test_end_num = self.data_num
        self.norm_data(train_end_num, valid_end_num, test_end_num)

        self.train_set, self.valid_set, self.test_set = self.split(train_end_num, valid_end_num, test_end_num)

    def norm_data(self, train_end_num, valid_end_num, test_end_num):
        train_part = self.raw_data[:train_end_num, :]
        val_part = self.raw_data[train_end_num:valid_end_num, :]
        test_part = self.raw_data[valid_end_num:test_end_num, :]

        # <class 'tuple'>: (82,)
        mean = np.mean(train_part, axis=0)
        stdev = np.std(train_part, axis=0)

        # in case the stdev=0,then we will get nan
        for i in range(len(stdev)):
            if stdev[i] < 0.00000001:
                stdev[i] = 1
        # <class 'tuple'>: (24336, 82)
        train_part = (train_part - mean) / stdev
        val_part = (val_part - mean) / stdev
        test_part = (test_part - mean) / stdev

        # <class 'tuple'>: (40560, 82)
        self.raw_data = np.concatenate((train_part, val_part, test_part))

        self.target_mean = torch.from_numpy(mean)[-1].float()
        self.target_stdev = torch.from_numpy(stdev)[-1].float()
        # if torch.cuda.is_available():
        #     self.target_mean = self.target_mean.cuda()
        #     self.target_stdev = self.target_stdev.cuda()

    # train_end_num: 15782  valid_end_num: 21043   test_end_num: 26304
    def split(self, train_end_num, valid_end_num, test_end_num):
        # train_set的range中第一个数选取的很有意思，结合下面的samplify，因为窗口大小是168，horizon是24，168+24=192，
        # 相当于在数组中从0开始第191个位置上式要预测的y，构成了一个(x、y)样本对, 依次向右滑动从而不断得到新的样本对，即samplify中的for循环，
        # 所以samplify中能够得到的样本个数就是idx_set即train_set的长度

        # train_set: range(191, 15782)
        train_set_index = range(self.window + self.horizon - 1, train_end_num)
        valid_set_index = range(train_end_num, valid_end_num)
        test_set_index = range(valid_end_num, test_end_num)

        # 可以看到下面的train训练集中X的格式和nlp中的格式是一模一样的，
        # 验证集和测试集原本就各占0.2，所以它们的长度相等时很正常的
        # train_set：list，包含X、Y两个元素，X：torch.Size([24297, 10, 82])     Y：torch.Size([24297, 30])
        train_set = self.samplify(train_set_index)
        # self.valid：list，包含X、Y两个元素，X：torch.Size([8112, 10, 82])      Y：torch.Size([8112, 30])
        valid_set = self.samplify(valid_set_index)
        # self.test：list，包含X、Y两个元素，X：torch.Size([8112, 10, 82])       Y：torch.Size([8112, 30])
        test_set = self.samplify(test_set_index)

        return train_set, valid_set, test_set

    def samplify(self, idx_set):
        n = len(idx_set)
        X = torch.zeros((n, self.window, self.feature_num))
        Y = torch.zeros((n, self.horizon))

        for i in range(n):
            end = idx_set[i] - self.horizon + 1
            start = end - self.window
            # X: torch.Size([31345, 168, 137]), Y: torch.Size([31345, 24, 137]), 注意这里用的是solar这个数据集
            X[i, :, :] = torch.from_numpy(self.raw_data[start:end, :self.feature_num])
            Y[i, :] = torch.from_numpy(self.raw_data[end:idx_set[i] + 1, -1])

        return X, Y

    def get_batches(self, inputs, targets, batch_size, shuffle=True):
        length_temp = len(inputs)
        length = length_temp - length_temp % batch_size
        if shuffle:
            index = torch.randperm(length)
        else:
            index = torch.LongTensor(range(length))
        start_idx = 0
        while start_idx < length:
            end_idx = min(length, start_idx + batch_size)
            excerpt = index[start_idx:end_idx]
            X = inputs[excerpt]
            Y = targets[excerpt]
            if torch.cuda.is_available():
                X = X.cuda()
                Y = Y.cuda()
            yield X, Y
            start_idx += batch_size


# # 记录的loss没有用到、epoch观察就会发现其实也没有用，因为并不是中继训练，而是还需要训练num_epoch轮，也没有记录Adam优化器的参数，
# # 只有encoder、decoder的参数，其实就相当于有了一个预训练的模型再从头训练
# def load_checkpoint(filename, enc=None, dec=None, g2c=False):
#     print("loading model...")
#     if g2c:  # load weights into CPU
#         checkpoint = torch.load(filename, map_location=lambda storage, loc: storage)
#     else:
#         checkpoint = torch.load(filename)
#     if enc and dec:
#         enc.load_state_dict(checkpoint["encoder_state_dict"])
#         dec.load_state_dict(checkpoint["decoder_state_dict"])
#     epoch = checkpoint["epoch"]
#     loss = checkpoint["loss"]
#     print("saved model: epoch = %d, loss = %f" % (checkpoint["epoch"], checkpoint["loss"]))
#     return epoch

# 参考代码：adaptive span
##############################################################################
# CHECKPOINT
##############################################################################
def load_checkpoint(checkpoint_path, model, optimizer, args):
    print(f'loading from a checkpoint at {checkpoint_path}')
    checkpoint_state = torch.load(checkpoint_path)
    log_file = checkpoint_state['log_file']
    epoch_num = checkpoint_state['epoch_num']  # next iteration
    model.load_state_dict(checkpoint_state['model'])
    optimizer.load_state_dict(checkpoint_state['optimizer'])
    best_val = checkpoint_state['best_val']
    best_epoch_num = checkpoint_state['best_epoch_num']
    early_stop_acc = checkpoint_state['early_stop_acc']
    accumulate_time = checkpoint_state['accumulate_time']

    return log_file, epoch_num + 1, best_val, best_epoch_num, early_stop_acc, accumulate_time


def save_checkpoint(checkpoint_path, log_file, epoch_num, model, optimizer, best_val, best_epoch_num, early_stop_acc,
                    accumulate_time):
    if checkpoint_path:
        checkpoint_state = {
            'log_file': log_file,
            'epoch_num': epoch_num,  # last completed iteration
            # todo 注意这里可能需要是model.module.state_dict()，中断一下看是否能加载
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'best_val': best_val,
            'best_epoch_num': best_epoch_num,
            'early_stop_acc': early_stop_acc,
            'accumulate_time': accumulate_time
        }

        torch.save(checkpoint_state, checkpoint_path)


def log_the_parameters(args, log_file):
    with open(log_file, 'a') as result_file:
        result_file.write(f'hyper parameters: ')
        # argparse打印参数见：https://stackoverflow.com/questions/27181084/how-to-iterate-over-arguments
        for key, val in vars(args).items():
            result_file.write(f'{key}:{val}, ')
        result_file.write('\n')


def get_curr_data_name(args):
    # 获取命令行里数据集路径里的文件名
    log_base = os.path.basename(args.data)
    # 把文件名的扩展去掉
    log_file_no_ext = os.path.splitext(log_base)[0]

    return log_file_no_ext


def get_curr_log_name(args):
    # log directory check, 参考：https://thispointer.com/how-to-create-a-directory-in-python/
    if not os.path.exists(args.log_dir):
        os.mkdir(args.log_dir)

    # 获取命令行里数据集路径里的文件名
    log_base = os.path.basename(args.data)
    # 把文件名的扩展去掉
    log_file_no_ext = os.path.splitext(log_base)[0]
    # 创建新的相关数据集的log文件
    curr_log_files = glob.glob(join(args.log_dir, log_file_no_ext + f'_{args.horizon}' + '*.txt'))
    if len(curr_log_files) != 0:
        file_names = [os.path.basename(name) for name in curr_log_files]
        file_names_no_ext = [os.path.splitext(name)[0] for name in file_names]
        # 用split而不用partition的原因见：https://www.quora.com/Whats-the-difference-between-partition-and-split-for-strings-in-Python
        nums = [int(name.split('_')[-1]) for name in file_names_no_ext]
        nums.sort()
        max = nums[-1]
        log_file = join(args.log_dir, f'{log_file_no_ext}_{args.horizon}_{max + 1}.txt')
    else:
        log_file = join(args.log_dir, f'{log_file_no_ext}_{args.horizon}_0.txt')

    return log_file


def get_curr_best_check_path(args):
    # 获取命令行里数据集路径里的文件名
    log_base = os.path.basename(args.data)
    # 把文件名的扩展去掉
    log_file_no_ext = os.path.splitext(log_base)[0]
    path_name = join(args.save, f'{log_file_no_ext}_{args.horizon}_step.pt')

    return path_name


def get_curr_checkpoint_path(args):
    # 获取命令行里数据集路径里的文件名
    log_base = os.path.basename(args.data)
    # 把文件名的扩展去掉
    log_file_no_ext = os.path.splitext(log_base)[0]
    path_name = join(args.checkpoints_dir, f'{log_file_no_ext}_{args.horizon}_step.pt')

    return path_name


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def load_data(args, train_percent=0.6, valid_percent=0.2):
    print('load data...')
    data_obj = Dataset(args, train_percent, valid_percent)

    return data_obj


def set_rand_seed(args):
    # 随机生成种子并保存在args里面，这样就不用每次实验都手动设置不同的种子的
    seed = random.randint(1, 1000000)
    args.seed = seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


def adjust_learning_rate(optimizer, epoch, lr_decay=0.3, lr_decay_epoch=5):
    """Decay learning rate by a factor of lr_decay every lr_decay_epoch epochs"""
    if epoch % lr_decay_epoch:
        return optimizer

    for param_group in optimizer.param_groups:
        param_group['lr'] *= lr_decay

    return optimizer
